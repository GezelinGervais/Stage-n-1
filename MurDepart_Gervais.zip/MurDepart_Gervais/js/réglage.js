var Vbat_fichier1,Vbat_fichier2,Vbat_fichier3,Vbat_fichier4,Vbat_fichier5,Vbat_fichier6;
var Vpanneau_fichier1,Vpanneau_fichier2,Vpanneau_fichier3,Vpanneau_fichier4,Vpanneau_fichier5,Vpanneau_fichier6;
var Vsysteme_fichier1,Vsysteme_fichier2,Vsysteme_fichier3,Vsysteme_fichier4,Vsysteme_fichier5,Vsysteme_fichier6;
var Ibat_fichier1,Ibat_fichier2,Ibat_fichier3,Ibat_fichier4,Ibat_fichier5,Ibat_fichier6;
var Ipanneau_fichier1,Ipanneau_fichier2,Ipanneau_fichier3,Ipanneau_fichier4,Ipanneau_fichier5,Ipanneau_fichier6;
var Isysteme_fichier1,Isysteme_fichier2,Isysteme_fichier3,Isysteme_fichier4,Isysteme_fichier5,Isysteme_fichier6;
var temperatures_fichier1,temperatures_fichier2,temperatures_fichier3,temperatures_fichier4,temperatures_fichier5,temperatures_fichier6;
var Ensoleillement_fichier1,Ensoleillement_fichier2,Ensoleillement_fichier3,Ensoleillement_fichier4,Ensoleillement_fichier5,Ensoleillement_fichier6;

window.addEventListener('scroll', retourTop);	
document.getElementById("btn").addEventListener('click', retourTop2);	

document.getElementById("red1").addEventListener('click', choixCouleur);
document.getElementById("green1").addEventListener('click', choixCouleur);
document.getElementById("blue1").addEventListener('click', choixCouleur);
document.getElementById("yellow1").addEventListener('click', choixCouleur);
document.getElementById("black1").addEventListener('click', choixCouleur);
document.getElementById("gray1").addEventListener('click', choixCouleur);
document.getElementById("purple1").addEventListener('click', choixCouleur);
document.getElementById("brown1").addEventListener('click', choixCouleur);
	
document.getElementById("Vbat").addEventListener('click', choixCourbe);
document.getElementById("Vbat_courbe1").addEventListener('click',choixCourbe);
document.getElementById("Vbat_courbe2").addEventListener('click',choixCourbe);
document.getElementById("Vbat_courbe3").addEventListener('click',choixCourbe);
document.getElementById("Vbat_courbe4").addEventListener('click',choixCourbe);
document.getElementById("Vbat_courbe5").addEventListener('click',choixCourbe);
document.getElementById("Vbat_courbe6").addEventListener('click',choixCourbe);

document.getElementById("Vbat").addEventListener('click', choixFichier);
document.getElementById("Vbat_fichier1").addEventListener('click',choixFichier);
document.getElementById("Vbat_fichier2").addEventListener('click',choixFichier);
document.getElementById("Vbat_fichier3").addEventListener('click',choixFichier);
document.getElementById("Vbat_fichier4").addEventListener('click',choixFichier);
document.getElementById("Vbat_fichier5").addEventListener('click',choixFichier);
document.getElementById("Vbat_fichier6").addEventListener('click',choixFichier);

document.getElementById("red2").addEventListener('click', choixCouleur);
document.getElementById("green2").addEventListener('click', choixCouleur);
document.getElementById("blue2").addEventListener('click', choixCouleur);
document.getElementById("yellow2").addEventListener('click', choixCouleur);
document.getElementById("black2").addEventListener('click', choixCouleur);
document.getElementById("gray2").addEventListener('click', choixCouleur);
document.getElementById("purple2").addEventListener('click', choixCouleur);
document.getElementById("brown2").addEventListener('click', choixCouleur);

document.getElementById("Vpanneau").addEventListener('click', choixCourbe);
document.getElementById("Vpanneau_courbe1").addEventListener('click',choixCourbe);
document.getElementById("Vpanneau_courbe2").addEventListener('click',choixCourbe);
document.getElementById("Vpanneau_courbe3").addEventListener('click',choixCourbe);
document.getElementById("Vpanneau_courbe4").addEventListener('click',choixCourbe);
document.getElementById("Vpanneau_courbe5").addEventListener('click',choixCourbe);
document.getElementById("Vpanneau_courbe6").addEventListener('click',choixCourbe);

document.getElementById("Vpanneau").addEventListener('click', choixFichier);
document.getElementById("Vpanneau_fichier1").addEventListener('click',choixFichier);
document.getElementById("Vpanneau_fichier2").addEventListener('click',choixFichier);
document.getElementById("Vpanneau_fichier3").addEventListener('click',choixFichier);
document.getElementById("Vpanneau_fichier4").addEventListener('click',choixFichier);
document.getElementById("Vpanneau_fichier5").addEventListener('click',choixFichier);
document.getElementById("Vpanneau_fichier6").addEventListener('click',choixFichier);

document.getElementById("red3").addEventListener('click', choixCouleur);
document.getElementById("green3").addEventListener('click', choixCouleur);
document.getElementById("blue3").addEventListener('click', choixCouleur);
document.getElementById("yellow3").addEventListener('click', choixCouleur);
document.getElementById("black3").addEventListener('click', choixCouleur);
document.getElementById("gray3").addEventListener('click', choixCouleur);
document.getElementById("purple3").addEventListener('click', choixCouleur);
document.getElementById("brown3").addEventListener('click', choixCouleur);

document.getElementById("Vsysteme").addEventListener('click', choixCourbe);
document.getElementById("Vsysteme_courbe1").addEventListener('click',choixCourbe);
document.getElementById("Vsysteme_courbe2").addEventListener('click',choixCourbe);
document.getElementById("Vsysteme_courbe3").addEventListener('click',choixCourbe);
document.getElementById("Vsysteme_courbe4").addEventListener('click',choixCourbe);
document.getElementById("Vsysteme_courbe5").addEventListener('click',choixCourbe);
document.getElementById("Vsysteme_courbe6").addEventListener('click',choixCourbe);

document.getElementById("Vsysteme").addEventListener('click', choixFichier);
document.getElementById("Vsysteme_fichier1").addEventListener('click',choixFichier);
document.getElementById("Vsysteme_fichier2").addEventListener('click',choixFichier);
document.getElementById("Vsysteme_fichier3").addEventListener('click',choixFichier);
document.getElementById("Vsysteme_fichier4").addEventListener('click',choixFichier);
document.getElementById("Vsysteme_fichier5").addEventListener('click',choixFichier);
document.getElementById("Vsysteme_fichier6").addEventListener('click',choixFichier);

document.getElementById("red4").addEventListener('click', choixCouleur);
document.getElementById("green4").addEventListener('click', choixCouleur);
document.getElementById("blue4").addEventListener('click', choixCouleur);
document.getElementById("yellow4").addEventListener('click', choixCouleur);
document.getElementById("black4").addEventListener('click', choixCouleur);
document.getElementById("gray4").addEventListener('click', choixCouleur);
document.getElementById("purple4").addEventListener('click', choixCouleur);
document.getElementById("brown4").addEventListener('click', choixCouleur);

document.getElementById("Ibat").addEventListener('click', choixCourbe);
document.getElementById("Ibat_courbe1").addEventListener('click',choixCourbe);
document.getElementById("Ibat_courbe2").addEventListener('click',choixCourbe);
document.getElementById("Ibat_courbe3").addEventListener('click',choixCourbe);
document.getElementById("Ibat_courbe4").addEventListener('click',choixCourbe);
document.getElementById("Ibat_courbe5").addEventListener('click',choixCourbe);
document.getElementById("Ibat_courbe6").addEventListener('click',choixCourbe);

document.getElementById("Ibat").addEventListener('click', choixFichier);
document.getElementById("Ibat_fichier1").addEventListener('click',choixFichier);
document.getElementById("Ibat_fichier2").addEventListener('click',choixFichier);
document.getElementById("Ibat_fichier3").addEventListener('click',choixFichier);
document.getElementById("Ibat_fichier4").addEventListener('click',choixFichier);
document.getElementById("Ibat_fichier5").addEventListener('click',choixFichier);
document.getElementById("Ibat_fichier6").addEventListener('click',choixFichier);

document.getElementById("red5").addEventListener('click', choixCouleur);
document.getElementById("green5").addEventListener('click', choixCouleur);
document.getElementById("blue5").addEventListener('click', choixCouleur);
document.getElementById("yellow5").addEventListener('click', choixCouleur);
document.getElementById("black5").addEventListener('click', choixCouleur);
document.getElementById("gray5").addEventListener('click', choixCouleur);
document.getElementById("purple5").addEventListener('click', choixCouleur);
document.getElementById("brown5").addEventListener('click', choixCouleur);

document.getElementById("Ipanneau").addEventListener('click', choixCourbe);
document.getElementById("Ipanneau_courbe1").addEventListener('click',choixCourbe);
document.getElementById("Ipanneau_courbe2").addEventListener('click',choixCourbe);
document.getElementById("Ipanneau_courbe3").addEventListener('click',choixCourbe);
document.getElementById("Ipanneau_courbe4").addEventListener('click',choixCourbe);
document.getElementById("Ipanneau_courbe5").addEventListener('click',choixCourbe);
document.getElementById("Ipanneau_courbe6").addEventListener('click',choixCourbe);

document.getElementById("Ipanneau").addEventListener('click', choixFichier);
document.getElementById("Ipanneau_fichier1").addEventListener('click',choixFichier);
document.getElementById("Ipanneau_fichier2").addEventListener('click',choixFichier);
document.getElementById("Ipanneau_fichier3").addEventListener('click',choixFichier);
document.getElementById("Ipanneau_fichier4").addEventListener('click',choixFichier);
document.getElementById("Ipanneau_fichier5").addEventListener('click',choixFichier);
document.getElementById("Ipanneau_fichier6").addEventListener('click',choixFichier);

document.getElementById("red6").addEventListener('click', choixCouleur);
document.getElementById("green6").addEventListener('click', choixCouleur);
document.getElementById("blue6").addEventListener('click', choixCouleur);
document.getElementById("yellow6").addEventListener('click', choixCouleur);
document.getElementById("black6").addEventListener('click', choixCouleur);
document.getElementById("gray6").addEventListener('click', choixCouleur);
document.getElementById("purple6").addEventListener('click', choixCouleur);
document.getElementById("brown6").addEventListener('click', choixCouleur);

document.getElementById("Isysteme").addEventListener('click', choixCourbe);
document.getElementById("Isysteme_courbe1").addEventListener('click',choixCourbe);
document.getElementById("Isysteme_courbe2").addEventListener('click',choixCourbe);
document.getElementById("Isysteme_courbe3").addEventListener('click',choixCourbe);
document.getElementById("Isysteme_courbe4").addEventListener('click',choixCourbe);
document.getElementById("Isysteme_courbe5").addEventListener('click',choixCourbe);
document.getElementById("Isysteme_courbe6").addEventListener('click',choixCourbe);

document.getElementById("Isysteme").addEventListener('click', choixFichier);
document.getElementById("Isysteme_fichier1").addEventListener('click',choixFichier);
document.getElementById("Isysteme_fichier2").addEventListener('click',choixFichier);
document.getElementById("Isysteme_fichier3").addEventListener('click',choixFichier);
document.getElementById("Isysteme_fichier4").addEventListener('click',choixFichier);
document.getElementById("Isysteme_fichier5").addEventListener('click',choixFichier);
document.getElementById("Isysteme_fichier6").addEventListener('click',choixFichier);

document.getElementById("red7").addEventListener('click', choixCouleur);
document.getElementById("green7").addEventListener('click', choixCouleur);
document.getElementById("blue7").addEventListener('click', choixCouleur);
document.getElementById("yellow7").addEventListener('click', choixCouleur);
document.getElementById("black7").addEventListener('click', choixCouleur);
document.getElementById("gray7").addEventListener('click', choixCouleur);
document.getElementById("purple7").addEventListener('click', choixCouleur);
document.getElementById("brown7").addEventListener('click', choixCouleur);

document.getElementById("temperatures").addEventListener('click', choixCourbe);
document.getElementById("temperatures_courbe1").addEventListener('click',choixCourbe);
document.getElementById("temperatures_courbe2").addEventListener('click',choixCourbe);
document.getElementById("temperatures_courbe3").addEventListener('click',choixCourbe);
document.getElementById("temperatures_courbe4").addEventListener('click',choixCourbe);
document.getElementById("temperatures_courbe5").addEventListener('click',choixCourbe);
document.getElementById("temperatures_courbe6").addEventListener('click',choixCourbe);

document.getElementById("temperatures").addEventListener('click', choixFichier);
document.getElementById("temperatures_fichier1").addEventListener('click',choixFichier);
document.getElementById("temperatures_fichier2").addEventListener('click',choixFichier);
document.getElementById("temperatures_fichier3").addEventListener('click',choixFichier);
document.getElementById("temperatures_fichier4").addEventListener('click',choixFichier);
document.getElementById("temperatures_fichier5").addEventListener('click',choixFichier);
document.getElementById("temperatures_fichier6").addEventListener('click',choixFichier);

document.getElementById("red8").addEventListener('click', choixCouleur);
document.getElementById("green8").addEventListener('click', choixCouleur);
document.getElementById("blue8").addEventListener('click', choixCouleur);
document.getElementById("yellow8").addEventListener('click', choixCouleur);
document.getElementById("black8").addEventListener('click', choixCouleur);
document.getElementById("gray8").addEventListener('click', choixCouleur);
document.getElementById("purple8").addEventListener('click', choixCouleur);
document.getElementById("brown8").addEventListener('click', choixCouleur);

document.getElementById("Ensoleillement").addEventListener('click', choixCourbe);
document.getElementById("Ensoleillement_courbe1").addEventListener('click',choixCourbe);
document.getElementById("Ensoleillement_courbe2").addEventListener('click',choixCourbe);
document.getElementById("Ensoleillement_courbe3").addEventListener('click',choixCourbe);
document.getElementById("Ensoleillement_courbe4").addEventListener('click',choixCourbe);
document.getElementById("Ensoleillement_courbe5").addEventListener('click',choixCourbe);
document.getElementById("Ensoleillement_courbe6").addEventListener('click',choixCourbe);

document.getElementById("Ensoleillement").addEventListener('click', choixFichier);
document.getElementById("Ensoleillement_fichier1").addEventListener('click',choixFichier);
document.getElementById("Ensoleillement_fichier2").addEventListener('click',choixFichier);
document.getElementById("Ensoleillement_fichier3").addEventListener('click',choixFichier);
document.getElementById("Ensoleillement_fichier4").addEventListener('click',choixFichier);
document.getElementById("Ensoleillement_fichier5").addEventListener('click',choixFichier);
document.getElementById("Ensoleillement_fichier6").addEventListener('click',choixFichier);

function choixCouleur(){
	var x = getComputedStyle(this).backgroundColor;
	if (this.id == "red1" || this.id == "green1" || this.id == "blue1" || this.id == "yellow1" || this.id == "black1" ||
		this.id == "gray1" || this.id == "purple1" || this.id == "brown1"){	
			if (document.getElementById("Vbat_courbe1").checked == true){
					g1.updateOptions({
						color : x
				});
			}
			if (document.getElementById("Vbat_courbe2").checked == true){
					g2.updateOptions({
						color : x
				});
			}
			
			if (document.getElementById("Vbat_courbe3").checked == true){
					g3.updateOptions({
						color : x
				});
			}
			if (document.getElementById("Vbat_courbe4").checked == true){
					g4.updateOptions({
						color : x
				});
			}
			if (document.getElementById("Vbat_courbe5").checked == true){
					g5.updateOptions({
						color : x
				});
			}
			if (document.getElementById("Vbat_courbe6").checked == true){
					g6.updateOptions({
						color : x
				});
			}
	}
	if (this.id == "red2" || this.id == "green2" || this.id == "blue2" || this.id == "yellow2" || this.id == "black2" ||
		this.id == "gray2" || this.id == "purple2" || this.id == "brown2"){	
			if (document.getElementById("Vpanneau_courbe1").checked == true){
					g1.updateOptions({
						color : x
				});
			}
			if (document.getElementById("Vpanneau_courbe2").checked == true){
					g2.updateOptions({
						color : x
				});
			}
			
			if (document.getElementById("Vpanneau_courbe3").checked == true){
					g3.updateOptions({
						color : x
				});
			}
			if (document.getElementById("Vpanneau_courbe4").checked == true){
					g4.updateOptions({
						color : x
				});
			}
			if (document.getElementById("Vpanneau_courbe5").checked == true){
					g5.updateOptions({
						color : x
				});
			}
			if (document.getElementById("Vpanneau_courbe6").checked == true){
					g6.updateOptions({
						color : x
				});
			}
		}
	if (this.id == "red3" || this.id == "green3" || this.id == "blue3" || this.id == "yellow3" || this.id == "black3" ||
		this.id == "gray3" || this.id == "purple3" || this.id == "brown3"){		
			if (document.getElementById("Vsysteme_courbe1").checked == true){
					g1.updateOptions({
						color : x
				});
			}
			if (document.getElementById("Vsysteme_courbe2").checked == true){
					g2.updateOptions({
						color : x
				});
			}
			
			if (document.getElementById("Vsysteme_courbe3").checked == true){
					g3.updateOptions({
						color : x
				});
			}
			if (document.getElementById("Vsysteme_courbe4").checked == true){
					g4.updateOptions({
						color : x
				});
			}
			if (document.getElementById("Vsysteme_courbe5").checked == true){
					g5.updateOptions({
						color : x
				});
			}
			if (document.getElementById("Vsysteme_courbe6").checked == true){
					g6.updateOptions({
						color : x
				});
			}
		}
	if (this.id == "red4" || this.id == "green4" || this.id == "blue4" || this.id == "yellow4" || this.id == "black4" ||
		this.id == "gray4" || this.id == "purple4" || this.id == "brown4"){		
			if (document.getElementById("Ibat_courbe1").checked == true){
					g1.updateOptions({
						color : x
				});
			}
			if (document.getElementById("Ibat_courbe2").checked == true){
					g2.updateOptions({
						color : x
				});
			}
			
			if (document.getElementById("Ibat_courbe3").checked == true){
					g3.updateOptions({
						color : x
				});
			}
			if (document.getElementById("Ibat_courbe4").checked == true){
					g4.updateOptions({
						color : x
				});
			}
			if (document.getElementById("Ibat_courbe5").checked == true){
					g5.updateOptions({
						color : x
				});
			}
			if (document.getElementById("Ibat_courbe6").checked == true){
					g6.updateOptions({
						color : x
				});
			}
		}
	if (this.id == "red5" || this.id == "green5" || this.id == "blue5" || this.id == "yellow5" || this.id == "black5" ||
		this.id == "gray5" || this.id == "purple5" || this.id == "brown5"){		
			if (document.getElementById("Ipanneau_courbe1").checked == true){
					g1.updateOptions({
						color : x
				});
			}
			if (document.getElementById("Ipanneau_courbe2").checked == true){
					g2.updateOptions({
						color : x
				});
			}
			
			if (document.getElementById("Ipanneau_courbe3").checked == true){
					g3.updateOptions({
						color : x
				});
			}
			if (document.getElementById("Ipanneau_courbe4").checked == true){
					g4.updateOptions({
						color : x
				});
			}
			if (document.getElementById("Ipanneau_courbe5").checked == true){
					g5.updateOptions({
						color : x
				});
			}
			if (document.getElementById("Ipanneau_courbe6").checked == true){
					g6.updateOptions({
						color : x
				});
			}
		}
	if (this.id == "red6" || this.id == "green6" || this.id == "blue6" || this.id == "yellow6" || this.id == "black6" ||
		this.id == "gray6" || this.id == "purple6" || this.id == "brown6"){	
			if (document.getElementById("Isysteme_courbe1").checked == true){
					g1.updateOptions({
						color : x
				});
			}
			if (document.getElementById("Isysteme_courbe2").checked == true){
					g2.updateOptions({
						color : x
				});
			}
			if (document.getElementById("Isysteme_courbe3").checked == true){
					g3.updateOptions({
						color : x
				});
			}
			if (document.getElementById("Isysteme_courbe4").checked == true){
					g4.updateOptions({
						color : x
				});
			}
			if (document.getElementById("Isysteme_courbe5").checked == true){
					g5.updateOptions({
						color : x
				});
			}
			if (document.getElementById("Isysteme_courbe6").checked == true){
					g6.updateOptions({
						color : x
				});
			}
		}
	if (this.id == "red7" || this.id == "green7" || this.id == "blue7" || this.id == "yellow7" || this.id == "black7" ||
		this.id == "gray7" || this.id == "purple7" || this.id == "brown7"){	
			if (document.getElementById("temperatures_courbe1").checked == true){
					g1.updateOptions({
						color : x
				});
			}
			if (document.getElementById("temperatures_courbe2").checked == true){
					g2.updateOptions({
						color : x
				});
			}
			
			if (document.getElementById("temperatures_courbe3").checked == true){
					g3.updateOptions({
						color : x
				});
			}
			if (document.getElementById("temperatures_courbe4").checked == true){
					g4.updateOptions({
						color : x
				});
			}
			if (document.getElementById("temperatures_courbe5").checked == true){
					g5.updateOptions({
						color : x
				});
			}
			if (document.getElementById("temperatures_courbe6").checked == true){
					g6.updateOptions({
						color : x
				});
			}
		}
	if (this.id == "red8" || this.id == "green8" || this.id == "blue8" || this.id == "yellow8" || this.id == "black8" ||
		this.id == "gray8" || this.id == "purple8" || this.id == "brown8"){		
			if (document.getElementById("Ensoleillement_courbe1").checked == true){
					g1.updateOptions({
						color : x
				});
			}
			if (document.getElementById("Ensoleillement_courbe2").checked == true){
					g2.updateOptions({
						color : x
				});
			}
			
			if (document.getElementById("Ensoleillement_courbe3").checked == true){
					g3.updateOptions({
						color : x
				});
			}
			if (document.getElementById("Ensoleillement_courbe4").checked == true){
					g4.updateOptions({
						color : x
				});
			}
			if (document.getElementById("Ensoleillement_courbe5").checked == true){
					g5.updateOptions({
						color : x
				});
			}
			if (document.getElementById("Ensoleillement_courbe6").checked == true){
					g6.updateOptions({
						color : x
				});
			}
		}
}

function choixCourbe(){
	if(document.getElementById("Vbat").checked==true && document.getElementById("Vbat_courbe1").checked == true){
		g1.updateOptions({
			file: Vbat_fichier1,
			visibility : [true]
		});
	} 
	if(document.getElementById("Vbat").checked==true && document.getElementById("Vbat_courbe2").checked == true){
		g2.updateOptions({
			file: Vbat_fichier2,
			visibility : [true]
		});
	} 
	if(document.getElementById("Vbat").checked==true && document.getElementById("Vbat_courbe3").checked == true){
		g3.updateOptions({
			file: Vbat_fichier3,
			visibility : [true]
		});
	}
	if(document.getElementById("Vbat").checked==true && document.getElementById("Vbat_courbe4").checked == true){
		g4.updateOptions({
			file: Vbat_fichier4,
			visibility : [true]
		});
	}
	if(document.getElementById("Vbat").checked==true && document.getElementById("Vbat_courbe5").checked == true){
		g5.updateOptions({
			file: Vbat_fichier5,
			visibility : [true]
		});
	}
	if(document.getElementById("Vbat").checked==true && document.getElementById("Vbat_courbe6").checked == true){
		g6.updateOptions({
			file: Vbat_fichier6,
			visibility : [true]
		});
	} 
	if (document.getElementById("Vpanneau").checked==true && document.getElementById("Vpanneau_courbe1").checked == true){
		g1.updateOptions({
			file: Vpanneau_fichier1,
			visibility : [true]
		});
	}
	
	if(document.getElementById("Vpanneau").checked==true && document.getElementById("Vpanneau_courbe2").checked == true){
		g2.updateOptions({
			file: Vpanneau_fichier2,
			visibility : [true]
		});
	}
	
	if(document.getElementById("Vpanneau").checked==true && document.getElementById("Vpanneau_courbe3").checked == true){
		g3.updateOptions({
			file: Vpanneau_fichier3,
			visibility : [true]
		});
	}
	 
	if(document.getElementById("Vpanneau").checked==true && document.getElementById("Vpanneau_courbe4").checked == true){
		g4.updateOptions({
			file: Vpanneau_fichier4,
			visibility : [true]
		});
	}
	
	if(document.getElementById("Vpanneau").checked==true && document.getElementById("Vpanneau_courbe5").checked == true){
		g5.updateOptions({
			file: Vpanneau_fichier5,
			visibility : [true]
		});
	}
	 
	if(document.getElementById("Vpanneau").checked==true && document.getElementById("Vpanneau_courbe6").checked == true){
		g6.updateOptions({
			file: Vpanneau_fichier6,
			visibility : [true]
		});
	}

	if (document.getElementById("Vsysteme").checked==true && document.getElementById("Vsysteme_courbe1").checked == true){
		g1.updateOptions({
			file: Vsysteme_fichier1,
			visibility : [true]
		});
	}
	
	if(document.getElementById("Vsysteme").checked==true && document.getElementById("Vsysteme_courbe2").checked == true){
		g2.updateOptions({
			file: Vsysteme_fichier2,
			visibility : [true]
		});
	}
	 
	if(document.getElementById("Vsysteme").checked==true && document.getElementById("Vsysteme_courbe3").checked == true){
		g3.updateOptions({
			file: Vsysteme_fichier3,
			visibility : [true]
		});
	}
	 
	if(document.getElementById("Vsysteme").checked==true && document.getElementById("Vsysteme_courbe4").checked == true){
		g4.updateOptions({
			file: Vsysteme_fichier4,
			visibility : [true]
		});
	}
	
	if(document.getElementById("Vsysteme").checked==true && document.getElementById("Vsysteme_courbe5").checked == true){
		g5.updateOptions({
			file: Vsysteme_fichier5,
			visibility : [true]
		});
	}

	if(document.getElementById("Vsysteme").checked==true && document.getElementById("Vsysteme_courbe6").checked == true){
		g6.updateOptions({
			file: Vsysteme_fichier6,
			visibility : [true]
		});
	}

	if (document.getElementById("Ibat").checked==true && document.getElementById("Ibat_courbe1").checked == true){
		g1.updateOptions({
			file: Ibat_fichier1,
			visibility : [true]
		});
	}

	if(document.getElementById("Ibat").checked==true && document.getElementById("Ibat_courbe2").checked == true){
		g2.updateOptions({
			file: Ibat_fichier2,
			visibility : [true]
		});
	}

	if(document.getElementById("Ibat").checked==true && document.getElementById("Ibat_courbe3").checked == true){
		g3.updateOptions({
			file: Ibat_fichier3,
			visibility : [true]
		});
	}

	if(document.getElementById("Ibat").checked==true && document.getElementById("Ibat_courbe4").checked == true){
		g4.updateOptions({
			file: Ibat_fichier4,
			visibility : [true]
		});
	}

	if(document.getElementById("Ibat").checked==true && document.getElementById("Ibat_courbe5").checked == true){
		g5.updateOptions({
			file: Ibat_fichier5,
			visibility : [true]
		});
	}

	if(document.getElementById("Ibat").checked==true && document.getElementById("Ibat_courbe6").checked == true){
		g6.updateOptions({
			file: Ibat_fichier6,
			visibility : [true]
		});
	}

	if (document.getElementById("Ipanneau").checked==true && document.getElementById("Ipanneau_courbe1").checked == true){
		g1.updateOptions({
			file: Ipannneau_fichier1,
			visibility : [true]
		});
	}

	if(document.getElementById("Ipanneau").checked==true && document.getElementById("Ipanneau_courbe2").checked == true){
		g2.updateOptions({
			file: Ipannneau_fichier2,
			visibility : [true]
		});
	}

	if(document.getElementById("Ipanneau").checked==true && document.getElementById("Ipanneau_courbe3").checked == true){
		g3.updateOptions({
			file: Ipannneau_fichier3,
			visibility : [true]
		});
	}

	if(document.getElementById("Ipanneau").checked==true && document.getElementById("Ipanneau_courbe4").checked == true){
		g4.updateOptions({
			file: Ipannneau_fichier4,
			visibility : [true]
		});
	}

	if(document.getElementById("Ipanneau").checked==true && document.getElementById("Ipanneau_courbe5").checked == true){
		g5.updateOptions({
			file: Ipannneau_fichier5,
			visibility : [true]
		});
	}

	if(document.getElementById("Ipanneau").checked==true && document.getElementById("Ipanneau_courbe6").checked == true){
		g6.updateOptions({
			file: Ipannneau_fichier6,
			visibility : [true]
		});
	}
	
	if (document.getElementById("Isysteme").checked==true && document.getElementById("Isysteme_courbe1").checked == true){
		g1.updateOptions({
			file: Isysteme_fichier1,
			visibility : [true]
		});
	}

	if(document.getElementById("Isysteme").checked==true && document.getElementById("Isysteme_courbe2").checked == true){
		g2.updateOptions({
			file: Isysteme_fichier2,
			visibility : [true]
		});
	}
	
	if(document.getElementById("Isysteme").checked==true && document.getElementById("Isysteme_courbe3").checked == true){
		g3.updateOptions({
			file: Isysteme_fichier3,
			visibility : [true]
		});
	}
	
	if(document.getElementById("Isysteme").checked==true && document.getElementById("Isysteme_courbe4").checked == true){
		g4.updateOptions({
			file: Isysteme_fichier4,
			visibility : [true]
		});
	}

	if(document.getElementById("Isysteme").checked==true && document.getElementById("Isysteme_courbe5").checked == true){
		g5.updateOptions({
			file: Isysteme_fichier5,
			visibility : [true]
		});
	}
	
	if (document.getElementById("Isysteme").checked==true && document.getElementById("Isysteme_courbe6").checked == true){
		g6.updateOptions({
			file: Isysteme_fichier6,
			visibility : [true]
		});
	}

	if (document.getElementById("temperatures").checked==true && document.getElementById("temperatures_courbe1").checked == true){
		g1.updateOptions({
			file: temperatures_fichier1,
			visibility : [true]
		});
	}

	if(document.getElementById("temperatures").checked==true && document.getElementById("temperatures_courbe2").checked == true){
		g2.updateOptions({
			file: temperatures_fichier2,
			visibility : [true]
		});
	}
	
	if(document.getElementById("temperatures").checked==true && document.getElementById("temperatures_courbe3").checked == true){
		g3.updateOptions({
			file: temperatures_fichier3,
			visibility : [true]
		});
	}
	
	if(document.getElementById("temperatures").checked==true && document.getElementById("temperatures_courbe4").checked == true){
		g4.updateOptions({
			file: temperatures_fichier4,
			visibility : [true]
		});
	}

	if(document.getElementById("temperatures").checked==true && document.getElementById("temperatures_courbe5").checked == true){
		g5.updateOptions({
			file: temperatures_fichier5,
			visibility : [true]
		});
	}


	if(document.getElementById("temperatures").checked==true && document.getElementById("temperatures_courbe6").checked == true){
		g6.updateOptions({
			file: temperatures_fichier6,
			visibility : [true]
		});
	}
	
	if (document.getElementById("Ensoleillement").checked==true && document.getElementById("Ensoleillement_courbe1").checked == true){
		g1.updateOptions({
			file: Ensoleillement_fichier1,
			visibility : [true]
		});
	}
	

	if(document.getElementById("Ensoleillement").checked==true && document.getElementById("Ensoleillement_courbe2").checked == true){
		g2.updateOptions({
			file: Ensoleillement_fichier2,
			visibility : [true]
		});
	}

	if(document.getElementById("Ensoleillement").checked==true && document.getElementById("Ensoleillement_courbe3").checked == true){
		g3.updateOptions({
			file: Ensoleillement_fichier3,
			visibility : [true]
		});
	}
	if(document.getElementById("Ensoleillement").checked==true && document.getElementById("Ensoleillement_courbe4").checked == true){
		g4.updateOptions({
			file: Ensoleillement_fichier4,
			visibility : [true]
		});
	}

	if(document.getElementById("Ensoleillement").checked==true && document.getElementById("Ensoleillement_courbe5").checked == true){
		g5.updateOptions({
			file: Ensoleillement_fichier5,
			visibility : [true]
		});
	}
	
	if(document.getElementById("Ensoleillement").checked==true && document.getElementById("Ensoleillement_courbe6").checked == true){
		g6.updateOptions({
			file: Ensoleillement_fichier6,
			visibility : [true]
		});
	}


	if ((document.getElementById("Vbat").checked==false || document.getElementById("Vbat_courbe1").checked == false) &&
		(document.getElementById("Vpanneau").checked==false || document.getElementById("Vpanneau_courbe1").checked == false) &&
		(document.getElementById("Vsysteme").checked==false || document.getElementById("Vsysteme_courbe1").checked == false) &&
		(document.getElementById("Ibat").checked==false || document.getElementById("Ibat_courbe1").checked == false) &&
		(document.getElementById("Ipanneau").checked==false || document.getElementById("Ipanneau_courbe1").checked == false) &&
		(document.getElementById("Isysteme").checked==false || document.getElementById("Isysteme_courbe1").checked == false) &&
		(document.getElementById("temperatures").checked==false || document.getElementById("temperatures_courbe1").checked == false) &&
		(document.getElementById("Ensoleillement").checked==false || document.getElementById("Ensoleillement_courbe1").checked == false))
	{
		g1.updateOptions({
			visibility : [false]
		});
	}
	if ((document.getElementById("Vbat").checked==false || document.getElementById("Vbat_courbe2").checked == false) &&
		(document.getElementById("Vpanneau").checked==false || document.getElementById("Vpanneau_courbe2").checked == false) &&
		(document.getElementById("Vsysteme").checked==false || document.getElementById("Vsysteme_courbe2").checked == false) &&
		(document.getElementById("Ibat").checked==false || document.getElementById("Ibat_courbe2").checked == false) &&
		(document.getElementById("Ipanneau").checked==false || document.getElementById("Ipanneau_courbe2").checked == false) &&
		(document.getElementById("Isysteme").checked==false || document.getElementById("Isysteme_courbe2").checked == false) &&
		(document.getElementById("temperatures").checked==false || document.getElementById("temperatures_courbe2").checked == false) &&
		(document.getElementById("Ensoleillement").checked==false || document.getElementById("Ensoleillement_courbe2").checked == false))
	{
		g2.updateOptions({
			visibility : [false]
		});
	}
	if ((document.getElementById("Vbat").checked==false || document.getElementById("Vbat_courbe3").checked == false) &&
		(document.getElementById("Vpanneau").checked==false || document.getElementById("Vpanneau_courbe3").checked == false) &&
		(document.getElementById("Vsysteme").checked==false || document.getElementById("Vsysteme_courbe3").checked == false) &&
		(document.getElementById("Ibat").checked==false || document.getElementById("Ibat_courbe3").checked == false)&&
		(document.getElementById("Ipanneau").checked==false || document.getElementById("Ipanneau_courbe3").checked == false)&&
		(document.getElementById("Isysteme").checked==false || document.getElementById("Isysteme_courbe3").checked == false)&&
		(document.getElementById("temperatures").checked==false || document.getElementById("temperatures_courbe3").checked == false)&&
		(document.getElementById("Ensoleillement").checked==false || document.getElementById("Ensoleillement_courbe3").checked == false))
	{
		g3.updateOptions({
			visibility : [false]
		});
	}
	if ((document.getElementById("Vbat").checked==false || document.getElementById("Vbat_courbe4").checked == false) &&
		(document.getElementById("Vpanneau").checked==false || document.getElementById("Vpanneau_courbe4").checked == false) &&
		(document.getElementById("Vsysteme").checked==false || document.getElementById("Vsysteme_courbe4").checked == false) &&
		(document.getElementById("Ibat").checked==false || document.getElementById("Ibat_courbe4").checked == false) &&
		(document.getElementById("Ipanneau").checked==false || document.getElementById("Ipanneau_courbe4").checked == false) &&
		(document.getElementById("Isysteme").checked==false || document.getElementById("Isysteme_courbe4").checked == false) &&
		(document.getElementById("temperatures").checked==false || document.getElementById("temperatures_courbe4").checked == false) &&
		(document.getElementById("Ensoleillement").checked==false || document.getElementById("Ensoleillement_courbe4").checked == false))
	{
		g4.updateOptions({
			visibility : [false]
		});
	}
	if ((document.getElementById("Vbat").checked==false || document.getElementById("Vbat_courbe5").checked == false) &&
		(document.getElementById("Vpanneau").checked==false || document.getElementById("Vpanneau_courbe5").checked == false) &&
		(document.getElementById("Vsysteme").checked==false || document.getElementById("Vsysteme_courbe5").checked == false) &&
		(document.getElementById("Ibat").checked==false || document.getElementById("Ibat_courbe5").checked == false) &&
		(document.getElementById("Ipanneau").checked==false || document.getElementById("Ipanneau_courbe5").checked == false) &&
		(document.getElementById("Isysteme").checked==false || document.getElementById("Isysteme_courbe5").checked == false) &&
		(document.getElementById("temperatures").checked==false || document.getElementById("temperatures_courbe5").checked == false) &&
		(document.getElementById("Ensoleillement").checked==false || document.getElementById("Ensoleillement_courbe5").checked == false))
	{
		g5.updateOptions({
			visibility : [false]
		});
	}
	if ((document.getElementById("Vbat").checked==false || document.getElementById("Vbat_courbe6").checked == false) &&
		(document.getElementById("Vpanneau").checked==false || document.getElementById("Vpanneau_courbe6").checked == false) &&
		(document.getElementById("Vsysteme").checked==false || document.getElementById("Vsysteme_courbe6").checked == false) &&
		(document.getElementById("Ibat").checked==false || document.getElementById("Ibat_courbe6").checked == false) &&
		(document.getElementById("Ipanneau").checked==false || document.getElementById("Ipanneau_courbe6").checked == false) &&
		(document.getElementById("Isysteme").checked==false || document.getElementById("Isysteme_courbe6").checked == false) &&
		(document.getElementById("temperatures").checked==false || document.getElementById("temperatures_courbe6").checked == false) &&
		(document.getElementById("Ensoleillement").checked==false || document.getElementById("Ensoleillement_courbe6").checked == false))
	{
		g6.updateOptions({
			visibility : [false]
		});
	}
	
}
function choixFichier(){
	if(document.getElementById("Vbat").checked==true && document.getElementById("Vbat_fichier1").checked == true){
		Vbat_fichier1="Vbat1.csv"
	}
	if(document.getElementById("Vbat").checked==true && document.getElementById("Vbat_fichier2").checked == true){
		Vbat_fichier2="Vbat2.csv"
	}
	if(document.getElementById("Vbat").checked==true && document.getElementById("Vbat_fichier3").checked == true){
		Vbat_fichier3="Vbat3.csv"
	}
	if(document.getElementById("Vbat").checked==true && document.getElementById("Vbat_fichier4").checked == true){
		Vbat_fichier4="Vbat4.csv"
	}
	if(document.getElementById("Vbat").checked==true && document.getElementById("Vbat_fichier5").checked == true){
		Vbat_fichier5="Vbat5.csv"
	}
	if(document.getElementById("Vbat").checked==true && document.getElementById("Vbat_fichier6").checked == true){
		Vbat_fichier6="Vbat6.csv"
	}
	if(document.getElementById("Vpanneau").checked==true && document.getElementById("Vpanneau_fichier1").checked == true){
		Vpanneau_fichier1="Vpanneau1.csv"
	}
	if(document.getElementById("Vpanneau").checked==true && document.getElementById("Vpanneau_fichier2").checked == true){
		Vpanneau_fichier2="Vpanneau2.csv"
	}
	if(document.getElementById("Vpanneau").checked==true && document.getElementById("Vpanneau_fichier3").checked == true){
		Vpanneau_fichier3="Vpanneau3.csv"
	}
	if(document.getElementById("Vpanneau").checked==true && document.getElementById("Vpanneau_fichier4").checked == true){
		Vpanneau_fichier4="Vpanneau4.csv"
	}
	if(document.getElementById("Vpanneau").checked==true && document.getElementById("Vpanneau_fichier5").checked == true){
		Vpanneau_fichier5="Vpanneau5.csv"
	}
	if(document.getElementById("Vpanneau").checked==true && document.getElementById("Vpanneau_fichier6").checked == true){
		Vpanneau_fichier6="Vpanneau6.csv"
	}
	if(document.getElementById("Vsysteme").checked==true && document.getElementById("Vsysteme_fichier1").checked == true){
		Vsysteme_fichier1="Vsysteme1.csv"
	}
	if(document.getElementById("Vsysteme").checked==true && document.getElementById("Vsysteme_fichier2").checked == true){
		Vsysteme_fichier2="Vsysteme2.csv"
	}
	if(document.getElementById("Vsysteme").checked==true && document.getElementById("Vsysteme_fichier3").checked == true){
		Vsysteme_fichier3="Vsysteme3.csv"
	}
	if(document.getElementById("Vsysteme").checked==true && document.getElementById("Vsysteme_fichier4").checked == true){
		Vsysteme_fichier4="Vsysteme4.csv"
	}
	if(document.getElementById("Vsysteme").checked==true && document.getElementById("Vsysteme_fichier5").checked == true){
		Vsysteme_fichier5="Vsysteme5.csv"
	}
	if(document.getElementById("Vsysteme").checked==true && document.getElementById("Vsysteme_fichier6").checked == true){
		Vsysteme_fichier6="Vsysteme6.csv"
	}
	if(document.getElementById("Ibat").checked==true && document.getElementById("Ibat_fichier1").checked == true){
		Ibat_fichier1="Ibat1.csv"
	}
	if(document.getElementById("Ibat").checked==true && document.getElementById("Ibat_fichier2").checked == true){
		Ibat_fichier2="Ibat2.csv"
	}
	if(document.getElementById("Ibat").checked==true && document.getElementById("Ibat_fichier3").checked == true){
		Ibat_fichier3="Ibat3.csv"
	}
	if(document.getElementById("Ibat").checked==true && document.getElementById("Ibat_fichier4").checked == true){
		Ibat_fichier4="Ibat4.csv"
	}
	if(document.getElementById("Ibat").checked==true && document.getElementById("Ibat_fichier5").checked == true){
		Ibat_fichier5="Ibat5.csv"
	}
	if(document.getElementById("Ibat").checked==true && document.getElementById("Ibat_fichier6").checked == true){
		Ibat_fichier6="Ibat6.csv"
	}
	if(document.getElementById("Ipanneau").checked==true && document.getElementById("Ipanneau_fichier1").checked == true){
		Ipannneau_fichier1="Ipanneau1.csv"
	}
	if(document.getElementById("Ipanneau").checked==true && document.getElementById("Ipanneau_fichier2").checked == true){
		Ipannneau_fichier2="Ipanneau2.csv"
	}
	if(document.getElementById("Ipanneau").checked==true && document.getElementById("Ipanneau_fichier3").checked == true){
		Ipannneau_fichier3="Ipanneau3.csv"
	}
	if(document.getElementById("Ipanneau").checked==true && document.getElementById("Ipanneau_fichier4").checked == true){
		Ipannneau_fichier4="Ipanneau4.csv"
	}
	if(document.getElementById("Ipanneau").checked==true && document.getElementById("Ipanneau_fichier5").checked == true){
		Ipannneau_fichier5="Ipanneau5.csv"
	}
	if(document.getElementById("Ipanneau").checked==true && document.getElementById("Ipanneau_fichier6").checked == true){
		Ipannneau_fichier6="Ipanneau6.csv"
	}
	if(document.getElementById("Isysteme").checked==true && document.getElementById("Isysteme_fichier1").checked == true){
		Isysteme_fichier1="Isysteme1.csv"
	}
	if(document.getElementById("Isysteme").checked==true && document.getElementById("Isysteme_fichier2").checked == true){
		Isysteme_fichier2="Isysteme2.csv"
	}
	if(document.getElementById("Isysteme").checked==true && document.getElementById("Isysteme_fichier3").checked == true){
		Isysteme_fichier3="Isysteme3.csv"
	}
	if(document.getElementById("Isysteme").checked==true && document.getElementById("Isysteme_fichier4").checked == true){
		Isysteme_fichier4="Isysteme4.csv"
	}
	if(document.getElementById("Isysteme").checked==true && document.getElementById("Isysteme_fichier5").checked == true){
		Isysteme_fichier5="Isysteme5.csv"
	}
	if(document.getElementById("Isysteme").checked==true && document.getElementById("Isysteme_fichier6").checked == true){
		Isysteme_fichier6="Isysteme6.csv"
	}
	if(document.getElementById("temperatures").checked==true && document.getElementById("temperatures_fichier1").checked == true){
		temperatures_fichier1="Temperatures1.csv"
	}
	if(document.getElementById("temperatures").checked==true && document.getElementById("temperatures_fichier2").checked == true){
		temperatures_fichier2="Temperatures2.csv"
	}
	if(document.getElementById("temperatures").checked==true && document.getElementById("temperatures_fichier3").checked == true){
		temperatures_fichier3="Temperatures3.csv"
	}
	if(document.getElementById("temperatures").checked==true && document.getElementById("temperatures_fichier4").checked == true){
		temperatures_fichier4="Temperatures4.csv"
	}
	if(document.getElementById("temperatures").checked==true && document.getElementById("temperatures_fichier5").checked == true){
		temperatures_fichier5="Temperatures5.csv"
	}
	if(document.getElementById("temperatures").checked==true && document.getElementById("temperatures_fichier6").checked == true){
		temperatures_fichier6="Temperatures6.csv"
	}
	if(document.getElementById("Ensoleillement").checked==true && document.getElementById("Ensoleillement_fichier1").checked == true){
		Ensoleillement_fichier1="Ensoleillement1.csv"
	}
	if(document.getElementById("Ensoleillement").checked==true && document.getElementById("Ensoleillement_fichier2").checked == true){
		Ensoleillement_fichier2="Ensoleillement2.csv"
	}
	if(document.getElementById("Ensoleillement").checked==true && document.getElementById("Ensoleillement_fichier3").checked == true){
		Ensoleillement_fichier3="Ensoleillement3.csv"
	}
	if(document.getElementById("Ensoleillement").checked==true && document.getElementById("Ensoleillement_fichier4").checked == true){
		Ensoleillement_fichier4="Ensoleillement4.csv"
	}
	if(document.getElementById("Ensoleillement").checked==true && document.getElementById("Ensoleillement_fichier5").checked == true){
		Ensoleillement_fichier5="Ensoleillement5.csv"
	}
	if(document.getElementById("Ensoleillement").checked==true && document.getElementById("Ensoleillement_fichier6").checked == true){
		Ensoleillement_fichier6="Ensoleillement6.csv"
	}

}

function retourTop() {
	if (window.scrollY > 200) 		
		document.getElementById("btn").style.right = "60px";
	else
		document.getElementById("btn").style.right = "-100px";	
}

function retourTop2() {
	document.getElementById("btn").style.right = "-100px";	
}