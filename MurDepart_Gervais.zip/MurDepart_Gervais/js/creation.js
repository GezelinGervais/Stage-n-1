g1 = new Dygraph(
	document.getElementById("graphdiv1"),
	 "Vbat.csv", // path to CSV file
	{
		visibility : [false]
	}          // options
);
g2=new Dygraph(
	document.getElementById("graphdiv2"),
	"Vpanneau.csv", // path to CSV file
	{
		visibility : [false]
	}   
);
g3=new Dygraph(
	document.getElementById("graphdiv3"),
	"Vsysteme.csv", // path to CSV file
	{
		visibility : [false]
	}   
);
g4=new Dygraph(
	document.getElementById("graphdiv4"),
	"Ibat.csv", // path to CSV file
	{
		visibility : [false]
	}   
);
g5=new Dygraph(
	document.getElementById("graphdiv5"),
	"Ipanneau.csv", // path to CSV file
	{
		visibility : [false]
	}   
);
g6=new Dygraph(
	document.getElementById("graphdiv6"),
	"Isysteme.csv", // path to CSV file
	{
		visibility : [false]
	}   
);
g7=new Dygraph(
	document.getElementById("graphdiv7"),
	"temperatures.csv", // path to CSV file
	{
		visibility : [false]
  }
);
g8=new Dygraph(
	document.getElementById("graphdiv8"),
	"Ensoleillement.csv", // path to CSV file
	{
		visibility : [false]
	}   
);

